
import imgmoto from "../assets/imagenmoto.jpg";
import { useState, useEffect } from "react";
import CommentForm from "./commentform";
import Listcomments from "./listcomments";

let post = () => {
    //manejo de estados de likes

    let [likes, setLike] = useState(0);

    //manejo de boton de comentarios

    let [btnComment, setBtnComment] = useState(false);
    let isShowComment = () => setBtnComment(!btnComment);
    //console.log(btnComment);

    //funcion para obtener comentarios del formulario
    let [textComment, settextComment] = useState("");
    let getCommentData = (comment) => {
        settextComment(comment);
    }
    // listado de comentarios
    let listcom = [
        { id: 1, text: "me gustan mucho las motos" },
        { id: 2, text: "me gusta la cafe racer" },

    ];

    let nextID = 3;
    let [id, setId] = useState(nextID);
    let [listData, setListData] = useState(listcom);
    //comprobar si hay un nuevo comentario

    useEffect(() => {
        if (textComment) {
            setListData(prev => [
                ...prev,
                { id: id, text: textComment }
            ]);
            setId(prevId => prevId + 1);
        }
    }, [textComment]);
    

    return (

        <div className="card" style={{ "width": "18rem" }}>

            <div className="card-body bg-dark text-white">
                <div className="post-header position-relative">
                    <img src="https://i.pravatar.cc/40" alt="perfil" className="avatar" />
                    <div>
                        <strong>La Moto </strong><br />
                        <small className=" text-light">Hace 18h ·🌐</small>
                    </div>
                    <div className="iconos-top">
                        <span className="me-2">⋯</span>
                        <span>✖</span>
                    </div>

                </div>
                <p className="post-text">Si no lloraste con esta moto, es porque no tenés corazón 🥲</p>
                <h5 className="card-title text-center">Moto Cafe Racer</h5>

                <p className="card-text"></p>
                <img src={imgmoto} clasName="card-img-top" alt="..." />

            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-around"
                 >
                    <span>👍😂😊 {likes}</span> <span>{listData.length} 🗨️</span>
                </li>
                <li className="list-group-item d-flex justify-content-around">
                    <button className="btn btn-secondary"
                        onClick={() => setLike(likes + 1)}
                    >👍 Likes</button>

                    <button className="btn btn-secondary"
                        onClick={isShowComment}
                    >🗨️ Comments</button>

                    <button   className="btn btn-secondary" 
                                 data-bs-toggle="modal" 
                                 data-bs-target="#shareModal">
                        🔗 Share
                    </button>
                </li>


            </ul>
            <div className="card-footer">
                {btnComment && <CommentForm getCommentData={getCommentData} />}
            </div>
            <Listcomments listcomData={listData} />



           

{/* Modal para compartir */}
<div className="modal fade" id="shareModal" tabIndex="-1" aria-labelledby="shareModalLabel" aria-hidden="true">
  <div className="modal-dialog">
    <div className="modal-content bg-dark text-white">
      <div className="modal-header">
        <h5 className="modal-title" id="shareModalLabel">Compartir Publicación</h5>
        <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div className="modal-body">
        <input 
          type="text" 
          className="form-control" 
          value="https://tupagina.com/post/123" 
          readOnly 
          onClick={(e) => e.target.select()} 
        />
        <small className="text-light mt-2 d-block">Haz clic para copiar el enlace</small>
      </div>
      <div className="modal-footer">
        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>


        </div>



    );
    

};
export default post;